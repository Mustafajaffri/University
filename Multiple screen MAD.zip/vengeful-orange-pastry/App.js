import React, { useState } from 'react';
import { View, Text, TouchableOpacity, StyleSheet, TextInput } from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { NavigationContainer } from '@react-navigation/native';
import { createNativeStackNavigator } from '@react-navigation/native-stack';

// Gradient Button Component
function GradientButton({ title, onPress }) {
  return (
    <TouchableOpacity style={styles.buttonContainer} onPress={onPress}>
      <LinearGradient
        colors={['#1e3c72', '#2a5298']}
        style={styles.buttonGradient}
      >
        <Text style={styles.buttonText}>{title}</Text>
      </LinearGradient>
    </TouchableOpacity>
  );
}

// Login Screen
function LoginScreen({ navigation }) {
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');

  return (
    <LinearGradient colors={['#141E30', '#243B55']} style={styles.container}>
      <Text style={styles.headerText}>🔐 Login</Text>
      <TextInput
        style={styles.input}
        placeholder="Username"
        placeholderTextColor="#aaa"
        value={username}
        onChangeText={setUsername}
      />
      <TextInput
        style={styles.input}
        placeholder="Password"
        placeholderTextColor="#aaa"
        value={password}
        onChangeText={setPassword}
        secureTextEntry
      />
      <GradientButton
        title="Submit"
        onPress={() => {
          if (username && password) {
            navigation.navigate('Home');
          } else {
            alert('Please enter both username and password');
          }
        }}
      />
    </LinearGradient>
  );
}

// Home Screen
function HomeScreen({ navigation }) {
  return (
    <LinearGradient colors={['#141E30', '#243B55']} style={styles.container}>
      <Text style={styles.headerText}>🏠 Home Screen</Text>
      <GradientButton title="Go to Profile" onPress={() => navigation.navigate('Profile')} />
      <GradientButton title="Go to Settings" onPress={() => navigation.navigate('Settings')} />
    </LinearGradient>
  );
}

// Profile Screen
function ProfileScreen({ navigation }) {
  return (
    <LinearGradient colors={['#141E30', '#243B55']} style={styles.container}>
      <Text style={styles.headerText}>👤 Profile Screen</Text>
      <GradientButton title="Go Back to Home" onPress={() => navigation.navigate('Home')} />
      <GradientButton title="Go to Settings" onPress={() => navigation.navigate('Settings')} />
    </LinearGradient>
  );
}

// Settings Screen
function SettingsScreen({ navigation }) {
  return (
    <LinearGradient colors={['#141E30', '#243B55']} style={styles.container}>
      <Text style={styles.headerText}>⚙️ Settings Screen</Text>
      <GradientButton title="Go Back to Home" onPress={() => navigation.navigate('Home')} />
      <GradientButton title="Go to Profile" onPress={() => navigation.navigate('Profile')} />
    </LinearGradient>
  );
}

// Stack Navigator Setup
const Stack = createNativeStackNavigator();

export default function App() {
  return (
    <NavigationContainer>
      <Stack.Navigator
        initialRouteName="Login"
        screenOptions={{
          headerStyle: { backgroundColor: '#1e3c72' },
          headerTintColor: '#fff',
          headerTitleStyle: { fontWeight: 'bold' },
        }}
      >
        <Stack.Screen name="Login" component={LoginScreen} />
        <Stack.Screen name="Home" component={HomeScreen} />
        <Stack.Screen name="Profile" component={ProfileScreen} />
        <Stack.Screen name="Settings" component={SettingsScreen} />
      </Stack.Navigator>
    </NavigationContainer>
  );
}

// Styles
const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  headerText: {
    fontSize: 28,
    fontWeight: 'bold',
    color: '#FFFFFF',
    marginBottom: 30,
    textShadowColor: 'rgba(0, 0, 0, 0.5)',
    textShadowOffset: { width: 2, height: 2 },
    textShadowRadius: 5,
  },
  input: {
    width: 300,
    height: 50,
    backgroundColor: '#fff',
    borderRadius: 25,
    paddingHorizontal: 15,
    fontSize: 16,
    marginVertical: 10,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.2,
    shadowRadius: 5,
  },
  buttonContainer: {
    marginVertical: 10,
    width: 250,
    borderRadius: 25,
    elevation: 5,
  },
  buttonGradient: {
    paddingVertical: 12,
    paddingHorizontal: 25,
    borderRadius: 25,
    alignItems: 'center',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.3,
    shadowRadius: 5,
  },
  buttonText: {
    color: '#fff',
    fontSize: 16,
    fontWeight: '600',
    textShadowColor: 'rgba(0, 0, 0, 0.5)',
    textShadowOffset: { width: 1, height: 1 },
    textShadowRadius: 3,
  },
});
